﻿namespace SportsPro.Models
{
    public class Country
    {
		public string CountryID { get; set; } = string.Empty;
		public string Name { get; set; } = string.Empty;
    }
}
